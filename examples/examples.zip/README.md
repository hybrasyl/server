# Sample Data

This directory contains sample XML data and Lua scripts (currently one
script..)  that can be used to test Hybrasyl and login to the
world. You can copy everything in this folder into Hybrasyl's data
directory (e.g. `My Documents\Hybrasyl\world`), or just unzip
`examples.zip` into your Hybrasyl directory.

You will need the map files `lod500.map`, `lod136.map`, and
`lod300.map`, which should be placed in the world directory as well,
in `mapfiles` (e.g. `Hybrasyl\world\mapfiles`).

